console.log("Auth page loaded");

function toggleForm() {
  const loginForm = document.getElementById("loginForm");
  const registerForm = document.getElementById("registerForm");
  const title = document.getElementById("formTitle");

  if (loginForm.style.display === "none") {
    loginForm.style.display = "block";
    registerForm.style.display = "none";
    title.innerText = "Login";
  } else {
    loginForm.style.display = "none";
    registerForm.style.display = "block";
    title.innerText = "Register";
  }
}

