import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";

import {
  getFirestore,
  doc,
  getDoc,
  updateDoc,
  collection,
  query,
  where,
  getDocs,
  onSnapshot,
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

import {
  getAuth,
  onAuthStateChanged,
  signOut,
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyAEO53PUiQtJOpIfTc4SNozxGtnYnCWTwg",
  authDomain: "interpreter-booking-2c704.firebaseapp.com",
  projectId: "interpreter-booking-2c704",
};

const app = initializeApp(firebaseConfig);

export const db = getFirestore(app);
export const auth = getAuth(app);

/* AUTH GUARD */
export function requireAuth(callback) {
  onAuthStateChanged(auth, (user) => {
    if (!user) {
      window.location.href = "auth.html";
    } else {
      callback(user);
    }
  });
}

/* LOGOUT */
export function logoutUser() {
  signOut(auth).then(() => {
    window.location.href = "auth.html";
  });
}
